#pragma once

#include "hook/hook.h"
#include "hook_manager/hook_manager.h"

namespace utils
{
	inline void *getProcAddressSafe(const char *module, const char *func)
	{
		const auto mod{ GetModuleHandleA(module) };

		if (!mod)
		{
			return nullptr;
		}

		return GetProcAddress(mod, func);
	}
}