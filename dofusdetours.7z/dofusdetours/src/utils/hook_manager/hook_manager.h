#pragma once

#include "../hook/hook.h"

namespace hook_manager
{
	bool initAllHooks();
	bool freeAllHooks();
}