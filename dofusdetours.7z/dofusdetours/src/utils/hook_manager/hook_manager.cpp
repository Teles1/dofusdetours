#include "hook_manager.h"

#include <vector>

std::vector<Hook *> hooks{};

Hook::Hook(void *init_fn)
{
	m_init_fn = init_fn;

	hooks.push_back(this);
}

bool hook_manager::initAllHooks()
{
	if (MH_Initialize() != MH_OK)
	{
		return false;
	}

	for (const auto &hook : hooks)
	{
		if (!hook)
		{
			return false;
		}

		const auto init{ hook->getInitFunc() };

		if (!init)
		{
			return false;
		}

		reinterpret_cast<void(__cdecl *)()>(init)();
	}

	return MH_EnableHook(MH_ALL_HOOKS) == MH_OK;
}

bool hook_manager::freeAllHooks()
{
	if (MH_Uninitialize() != MH_OK)
	{
		return false;
	}

	return false;
}