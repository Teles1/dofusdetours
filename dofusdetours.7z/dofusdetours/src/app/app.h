#pragma once

#include "../utils/utils.h"

namespace app
{
	bool load();
	bool unload();
}